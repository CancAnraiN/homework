# Network Applications Programming - Homework4 (TicTacToe)
## Made By B073040011 柯冠宇

### Bulid:
+ Use `java Server.java`, then execute `java Client.java` twice in different terminal to play TicTacToe in this program .

### NOTE:
+ 1: 
	When player made mistake(invalid move),my program will send message to tell them.But it will stuck too. I dont figure it out yet.
