# Network Applications Programming - Homework3(On-line chatting service)(Multiple Thread)
## Made By B073040011 柯冠宇

### Bulid:
+ Use `make` in both directory **client** and **server** to build this program .

### Description:
+ 1:
    Use `./client` to start the program.
    Use `./server` to activate server.
+ 2:
    client use ` connect 127.0.0.1 8989 "UserName" ` to connect with server .
+ 3:
    Then input "Name" or "chatroom" to decide unicast or multicast send
+ 4:
	Input `bye` to disconnect server;End server with `CTRL+C` 


### NOTE:
+ 1: 
	I didn't complete off line messages
+ 2:
	I had a problem about that server can't get the command,but I solved.
	why? Because of my stupid brain to confuse the parameter which used to get    	command.
